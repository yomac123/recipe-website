// Search functionality 
function searchDishes() {
  const searchInput = document.getElementById('searchBar').value.toLowerCase();
  const dishLinks = document.getElementById('dishLinks').getElementsByTagName('a');

  for (let i = 0; i < dishLinks.length; i++) {
    const dishName = dishLinks[i].innerText.toLowerCase();
    if (dishName.includes(searchInput)) {
      dishLinks[i].style.display = '';
    } else {
      dishLinks[i].style.display = 'none';
    }
  }
}

// Load comments from local storage
function loadComments(dish) {
  const comments = JSON.parse(localStorage.getItem(dish) || '[]');
  const commentSection = document.getElementById('comments');
  commentSection.innerHTML = '';
  comments.forEach(comment => {
    const newComment = document.createElement('div');
    newComment.innerHTML = `<strong>${comment.name}:</strong> <p>${comment.feedback}</p>`;
    commentSection.appendChild(newComment);
  });
}

// Save comment to local storage
function saveComment(dish, name, feedback) {
  const comments = JSON.parse(localStorage.getItem(dish) || '[]');
  comments.push({ name, feedback });
  localStorage.setItem(dish, JSON.stringify(comments));
}

// Handling feedback form submission and displaying comments
document.addEventListener('DOMContentLoaded', function () {
  const dish = document.title; // Use the title as the dish identifier

  // Load existing comments
  loadComments(dish);

  const forms = document.getElementsByTagName('form');
  for (let i = 0; i < forms.length; i++) {
    forms[i].addEventListener('submit', function (event) {
      event.preventDefault();
      const name = this.elements['name'].value;
      const feedback = this.elements['feedback'].value;

      saveComment(dish, name, feedback);

      const commentSection = document.getElementById('comments');
      const newComment = document.createElement('div');
      newComment.innerHTML = `<strong>${name}:</strong> <p>${feedback}</p>`;
      commentSection.appendChild(newComment);

      this.reset();
    });
  }
});
